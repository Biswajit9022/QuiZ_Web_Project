document.addEventListener("DOMContentLoaded", function () {
    const quizContainer = document.getElementById("quiz-container");
    const submitButton = document.getElementById("submit-btn");
    const timerElement = document.getElementById("timer");
    const prevButton = document.getElementById("prev-btn");
    const nextButton = document.getElementById("next-btn");
    const progressBar = document.getElementById("progress-bar");
    const progressBarInner = document.createElement("div");
    progressBarInner.className = "progress-bar-inner";
    progressBar.appendChild(progressBarInner);

    let timeLeft = 300; // 5 minutes in seconds
    let shuffledQuestions;
    let timerInterval; // Declare the timerInterval outside the fetch block
    let currentQuestionIndex = 0;

    // Fetch the questions from the JSON file
    fetch("ML_questions.json")
        .then(response => response.json())
        .then(questions => {
            // Shuffle the questions
            shuffledQuestions = shuffleArray(questions).slice(0, 10);

            // Build and display the quiz
            shuffledQuestions.forEach((question, index) => {
                const questionElement = document.createElement("div");
                questionElement.className = "question";
                questionElement.style.display = index === 0 ? "block" : "none";
                questionElement.innerHTML = `
                    <p>${index + 1}. ${question.Question}</p>
                    ${generateOptions(question, index)}
                `;
                quizContainer.appendChild(questionElement);
            });

            // Start the countdown timer
            startTimer();

            // Update progress bar
            updateProgressBar();
        })
        .catch(error => console.error("Error fetching questions:", error));

    // Event listener for the submit button
    submitButton.addEventListener("click", function () {
        clearInterval(timerInterval);
        // Submit the quiz
        submitQuiz();
    });

    // Event listener for next button
    nextButton.addEventListener("click", function () {
        if (currentQuestionIndex < shuffledQuestions.length - 1) {
            currentQuestionIndex++;
            updateQuiz();
        }
    });

    // Event listener for previous button
    prevButton.addEventListener("click", function () {
        if (currentQuestionIndex > 0) {
            currentQuestionIndex--;
            updateQuiz();
        }
    });

    // Helper function to start the countdown timer
    function startTimer() {
        // Clear the existing interval before starting a new one
        clearInterval(timerInterval);
    
        timerInterval = setInterval(function () {
            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                // Time is up, automatically submit the quiz
                submitQuiz();
            } else {
                timerElement.textContent = formatTime(timeLeft);
                updateProgressBar(); // Update progress bar more frequently
                timeLeft--;
            }
        }, 1000); // Adjusted interval to 1000 milliseconds (1 second)
    }

    // Helper function to update the quiz display based on currentQuestionIndex
    function updateQuiz() {
        const questionElements = document.querySelectorAll(".question");
        questionElements.forEach((element, index) => {
            if (index === currentQuestionIndex) {
                element.style.display = "block";
            } else {
                element.style.display = "none";
            }
        });
        updateProgressBar();
        startTimer();
    }

    // Helper function to update the progress bar
    function updateProgressBar() {
        const progress = (currentQuestionIndex + 1) / shuffledQuestions.length * 100;
        progressBarInner.style.width = `${progress}%`;
    }

    // Event listener for the submit button
    submitButton.addEventListener("click", function () {
        clearInterval(timerInterval);
        // Submit the quiz
        submitQuiz();
    });

    // Helper function to shuffle an array
    function shuffleArray(array) {
        return array.sort(() => Math.random() - 0.5);
    }

    // Helper function to generate HTML for options
    function generateOptions(question, questionIndex) {
        const options = ["Option A", "Option B", "Option C", "Option D"];
        return options.map(optionKey => `
            <input type="radio" name="q${questionIndex}" value="${question[optionKey]}" required>
            <label>${question[optionKey]}</label><br>
        `).join('');
    }

    // Helper function to format time in MM:SS format
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
    }

    // Helper function to calculate the score
    function calculateScore() {
        let score = 0;
        shuffledQuestions.forEach(question => {
            const selectedOption = document.querySelector(`input[name="q${shuffledQuestions.indexOf(question)}"]:checked`);
            if (selectedOption && selectedOption.value === question["Answer"]) {
                score++;
            }
        });
        return score;
    }

    // Helper function to submit the quiz
    function submitQuiz() {
        const score = calculateScore();
        
        // Store score and total number of questions in local storage
        localStorage.setItem('quizScore', score);
        localStorage.setItem('totalQuestions', shuffledQuestions.length);
    
        // Redirect to a new page to display the score
        window.location.href = 'score.html';
    }
    
}); 